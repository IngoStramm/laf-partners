jQuery(document).ready(function($) {
	// fitVids.
	$('.body');
});
